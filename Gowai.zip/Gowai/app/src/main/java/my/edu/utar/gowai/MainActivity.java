package my.edu.utar.gowai;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText etTotalBill, etNumPeople;
    private Button btnEqualBreakdown, btnCustomBreakdown, btnSaveResults, btnShareResults;
    private TextView tvResults;
    private List<Double> individualAmounts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etTotalBill = findViewById(R.id.etTotalBill);
        etNumPeople = findViewById(R.id.etNumPeople);
        btnEqualBreakdown = findViewById(R.id.btnEqualBreakdown);
        btnCustomBreakdown = findViewById(R.id.btnCustomBreakdown);
        btnSaveResults = findViewById(R.id.btnSaveResults);
        btnShareResults = findViewById(R.id.btnShareResults);
        tvResults = findViewById(R.id.tvResults);

        individualAmounts = new ArrayList<>();

        btnEqualBreakdown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateEqualBreakdown();
            }
        });

        btnCustomBreakdown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateCustomBreakdown();
            }
        });

        btnSaveResults.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveResults();
            }
        });

        btnShareResults.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareResults();
            }
        });
    }

    private void calculateEqualBreakdown() {
        if (!TextUtils.isEmpty(etTotalBill.getText().toString()) && !TextUtils.isEmpty(etNumPeople.getText().toString())) {
            double totalBill = Double.parseDouble(etTotalBill.getText().toString());
            int numPeople = Integer.parseInt(etNumPeople.getText().toString());
            double amountPerPerson = totalBill / numPeople;
            individualAmounts.clear();
            for (int i = 0; i < numPeople; i++) {
                individualAmounts.add(amountPerPerson);
            }
            displayResults();
        } else {
            Toast.makeText(this, "Please enter the total bill and number of people.", Toast.LENGTH_SHORT).show();
        }
    }

    private void calculateCustomBreakdown() {
        if (!TextUtils.isEmpty(etTotalBill.getText().toString()) && !TextUtils.isEmpty(etNumPeople.getText().toString())) {
            double totalBill = Double.parseDouble(etTotalBill.getText().toString());
            int numPeople = Integer.parseInt(etNumPeople.getText().toString());

            boolean isPercentage = true;
            individualAmounts.clear();

            if (isPercentage) {
                // Implement custom breakdown by percentage.
                double[] percentages = {0.25, 0.35, 0.40}; // Replace these values with the user's input.
                for (double percentage : percentages) {
                    double amount = totalBill * percentage / numPeople;
                    individualAmounts.add(amount);
                }
            } else {
                // Implement custom breakdown by ratio.
                int[] ratios = {5, 7, 8}; // Replace these values with the user's input.
                int totalRatio = 0;
                for (int ratio : ratios) {
                    totalRatio += ratio;
                }
                for (int i = 0; i < ratios.length; i++) {
                    double amount = totalBill * ratios[i] / totalRatio;
                    individualAmounts.add(amount);
                }
            }

            displayResults();
        } else {
            Toast.makeText(this, "Please enter the total bill and number of people.", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayResults() {
        StringBuilder resultBuilder = new StringBuilder();
        for (int i = 0; i < individualAmounts.size(); i++) {
            resultBuilder.append("Person ").append(i + 1).append(": RM").append(String.format("%.2f", individualAmounts.get(i))).append("\n");
        }
        tvResults.setText(resultBuilder.toString());
    }

    private void saveResults() {
        if (individualAmounts.isEmpty()) {
            Toast.makeText(this, "No results to save.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Convert the list of individualAmounts to a comma-separated string.
        StringBuilder sb = new StringBuilder();
        for (Double amount : individualAmounts) {
            sb.append(amount).append(",");
        }
        String resultsString = sb.toString();

        // Save the results string to SharedPreferences.
        SharedPreferences sharedPreferences = getSharedPreferences("BillBreakdownResults", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("results", resultsString);
        editor.apply();

        Toast.makeText(this, "Results saved.", Toast.LENGTH_SHORT).show();
    }

    private void shareResults() {
        // Implement the logic to share the bill break-down results via WhatsApp, email, etc. (optional).
        Intent sharingIntent = new Intent(Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");
        sharingIntent.putExtra(Intent.EXTRA_TEXT, tvResults.getText().toString());
        startActivity(Intent.createChooser(sharingIntent, "Share results via"));
    }
}